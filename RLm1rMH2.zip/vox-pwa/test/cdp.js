/* Petit pilote CDP : lance Chrome headless sur l'app Vox et rend une page pilotable.
   Partage par test/e2e.js et test/a11y.js. */
'use strict';

const { spawn } = require('node:child_process');
const path = require('node:path');
const os = require('node:os');

const CHROME = process.env.CHROME_BIN || '/usr/local/bin/google-chrome';
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function openApp(options) {
  const opts = options || {};
  const port = opts.port || '8123';
  const debugPort = opts.debugPort || '9333';
  const width = opts.width || 430;
  const height = opts.height || 1600;
  const appUrl = opts.url || `http://127.0.0.1:${port}/`;
  const userDataDir = path.join(os.tmpdir(), 'vox-test-' + Date.now() + '-' + Math.floor(Math.random() * 1e6));

  const chrome = spawn(CHROME, [
    '--headless=new',
    '--no-sandbox',
    '--disable-gpu',
    '--hide-scrollbars',
    '--mute-audio',
    `--remote-debugging-port=${debugPort}`,
    `--user-data-dir=${userDataDir}`,
    `--window-size=${width},${height}`,
    'about:blank'
  ], { stdio: 'ignore' });

  const close = () => {
    try { chrome.kill('SIGKILL'); } catch (e) { /* deja mort */ }
  };

  let target = null;
  for (let i = 0; i < 60; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${debugPort}/json/list`);
      const list = await res.json();
      target = list.find((t) => t.type === 'page');
      if (target) break;
    } catch (e) { /* chrome pas encore pret */ }
    await sleep(250);
  }
  if (!target) {
    close();
    throw new Error('Chrome headless ne repond pas sur le port de debug ' + debugPort);
  }

  const ws = new WebSocket(target.webSocketDebuggerUrl);
  const pending = new Map();
  const pageErrors = [];
  let nextId = 1;

  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve, { once: true });
    ws.addEventListener('error', reject, { once: true });
  });

  ws.addEventListener('message', (event) => {
    const msg = JSON.parse(event.data);
    if (msg.id && pending.has(msg.id)) {
      const entry = pending.get(msg.id);
      pending.delete(msg.id);
      if (msg.error) entry.reject(new Error(JSON.stringify(msg.error)));
      else entry.resolve(msg.result);
      return;
    }
    if (msg.method === 'Runtime.exceptionThrown') {
      const details = msg.params.exceptionDetails;
      pageErrors.push(details.text + ' ' +
        ((details.exception && details.exception.description) || ''));
    }
    if (msg.method === 'Log.entryAdded' && msg.params.entry.level === 'error') {
      pageErrors.push(msg.params.entry.text);
    }
  });

  const send = (method, params) => new Promise((resolve, reject) => {
    const id = nextId++;
    pending.set(id, { resolve, reject });
    ws.send(JSON.stringify({ id, method, params: params || {} }));
  });

  const evaluate = async (expression) => {
    const res = await send('Runtime.evaluate', {
      expression,
      awaitPromise: true,
      returnByValue: true
    });
    if (res.exceptionDetails) throw new Error(res.exceptionDetails.text);
    return res.result.value;
  };

  await send('Runtime.enable');
  await send('Log.enable');
  await send('Page.enable');
  await send('Page.navigate', { url: appUrl });
  await sleep(opts.settleMs || 2500);

  return {
    appUrl,
    pageErrors,
    send,
    evaluate,
    sleep,
    async reload(waitMs) {
      await send('Page.reload');
      await sleep(waitMs || 2200);
    },
    close() {
      try { ws.close(); } catch (e) { /* deja ferme */ }
      close();
    }
  };
}

module.exports = { openApp, sleep, CHROME };
