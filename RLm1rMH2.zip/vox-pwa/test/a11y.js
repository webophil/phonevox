/* Controle d'accessibilite (axe-core, WCAG 2.1 A/AA) sur Vox, dans Chrome headless.
   Usage : python3 -m http.server 8123 & puis node test/a11y.js [port] */
'use strict';

const { openApp } = require('./cdp');

const PORT = process.argv[2] || '8123';
const AXE_URL = 'https://cdn.jsdelivr.net/npm/axe-core@4.10.2/axe.min.js';

async function main() {
  const app = await openApp({ port: PORT });
  let failures = 0;
  try {
    const res = await fetch(AXE_URL);
    if (!res.ok) throw new Error('axe-core indisponible : HTTP ' + res.status);
    const source = await res.text();

    const injected = await app.evaluate(`(() => {
      ${source}
      return typeof axe === 'object' && typeof axe.run === 'function';
    })()`);
    if (!injected) throw new Error('axe-core ne s est pas charge dans la page');

    const violations = await app.evaluate(`
      axe.run(document, {
        runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'] }
      }).then(function (r) {
        return r.violations.map(function (v) {
          return {
            id: v.id,
            impact: v.impact,
            help: v.help,
            nodes: v.nodes.slice(0, 4).map(function (n) { return n.target.join(' '); })
          };
        });
      })
    `);

    if (!violations.length) {
      console.log('OK    aucune violation WCAG 2.1 A/AA detectee');
    } else {
      failures = violations.length;
      violations.forEach(function (v) {
        console.log('FAIL  [' + v.impact + '] ' + v.id + ' : ' + v.help);
        v.nodes.forEach(function (t) { console.log('        ' + t); });
      });
    }

    /* etat reel de quelques points non couverts par axe */
    const spot = await app.evaluate(`(() => {
      const mic = document.getElementById('micBtn');
      const ta = document.getElementById('transcript');
      const label = document.querySelector('label[for="transcript"]');
      return {
        micName: mic.getAttribute('aria-label'),
        micPressed: mic.getAttribute('aria-pressed'),
        transcriptLabel: label ? label.textContent.trim() : null,
        liveRegions: document.querySelectorAll('[aria-live]').length,
        lang: document.documentElement.lang,
        h1: document.querySelectorAll('h1').length
      };
    })()`);
    console.log('\nReperes :', JSON.stringify(spot, null, 0));
  } finally {
    app.close();
  }

  console.log(failures === 0 ? '\nACCESSIBILITE OK' : `\n${failures} violation(s)`);
  process.exit(failures === 0 ? 0 : 1);
}

main().catch(function (err) {
  console.error('ECHEC :', err.message);
  process.exit(1);
});
