/* Test de bout en bout de Vox : Chrome headless pilote par CDP.
   Usage : python3 -m http.server 8123 & puis node test/e2e.js [port] */
'use strict';

const { openApp } = require('./cdp');

const PORT = process.argv[2] || '8123';
let failures = 0;

function check(name, ok, detail) {
  console.log(`${ok ? 'OK  ' : 'FAIL'}  ${name}${detail ? '  -> ' + detail : ''}`);
  if (!ok) failures++;
}

async function main() {
  const app = await openApp({ port: PORT });
  try {
    /* 1. la coque est en place */
    const shell = await app.evaluate(`(() => ({
      flags: document.querySelectorAll('.flag').length,
      sources: document.querySelectorAll('#sourceLang option').length,
      cards: document.querySelectorAll('.card').length,
      cardsWithFlag: document.querySelectorAll('.card-head svg').length,
      title: document.title
    }))()`);
    check('16 drapeaux rendus', shell.flags === 16, String(shell.flags));
    check('langues de dictee listees', shell.sources >= 17, String(shell.sources));
    check('carte de depart rendue', shell.cards === 1 && shell.cardsWithFlag === 1, JSON.stringify(shell.cards));

    /* 2. traduire vers l'espagnol */
    const started = Date.now();
    await app.evaluate(`document.querySelector('.flag[data-code="es"]').click()`);
    let esCard = null;
    for (let i = 0; i < 40; i++) {
      await app.sleep(500);
      esCard = await app.evaluate(`(() => {
        const node = document.querySelector('.card');
        if (!node) return null;
        const txt = node.querySelector('.card-text');
        return {
          title: (node.querySelector('.card-title') || {}).textContent || '',
          value: txt ? txt.value : '',
          error: (node.querySelector('.card-error') || {}).textContent || '',
          loading: !!node.querySelector('.skeleton'),
          clipped: txt ? txt.scrollHeight > txt.clientHeight + 2 : false
        };
      })()`);
      if (esCard && !esCard.loading) break;
    }
    const secs = ((Date.now() - started) / 1000).toFixed(1);
    check('carte espagnole creee et remplie',
      !!esCard && esCard.value.length > 10 && esCard.title === 'Espagnol',
      esCard ? `${esCard.title} / ${secs}s / ${esCard.value.slice(0, 60)}` : 'aucune carte');
    check('aucune erreur de traduction affichee', !!esCard && !esCard.error, esCard && esCard.error);
    check('texte traduit entier dans la zone', !!esCard && !esCard.clipped,
      esCard ? 'clipped=' + esCard.clipped : '');

    /* 3. Lire bascule l'etat du bouton */
    await app.evaluate(`(document.querySelector('.card [data-speak]') || {click(){}}).click()`);
    await app.sleep(300);
    const speakState = await app.evaluate(`(() => {
      const b = document.querySelector('.card [data-speak]');
      return {
        pressed: b.getAttribute('aria-pressed'),
        label: (b.querySelector('.speak-label') || {}).textContent
      };
    })()`);
    check('Lire pilote l etat du bouton', speakState.label === 'Lire' || speakState.label === 'Arreter',
      JSON.stringify(speakState));

    /* 4. persistance apres rechargement */
    await app.evaluate(`(() => {
      const ta = document.getElementById('transcript');
      ta.value = 'Test de persistance Vox.';
      ta.dispatchEvent(new Event('input'));
      return true;
    })()`);
    await app.sleep(400);
    await app.reload();
    const persisted = await app.evaluate(`({
      text: document.getElementById('transcript').value,
      cards: document.querySelectorAll('.card').length
    })`);
    check('texte et cartes conserves apres rechargement',
      persisted.text.indexOf('persistance') >= 0 && persisted.cards >= 1,
      JSON.stringify(persisted));

    /* 5. service worker actif */
    const swState = await app.evaluate(
      `navigator.serviceWorker.getRegistration().then(r => r ? 'active' : 'none').catch(() => 'unsupported')`);
    check('service worker enregistre', swState !== 'unsupported', String(swState));

    /* 6. suppression d'une carte */
    await app.evaluate(`document.querySelector('.card .ghost.tiny').click()`);
    await app.sleep(300);
    const afterDelete = await app.evaluate(`document.querySelectorAll('.card').length`);
    check('carte supprimee', afterDelete === persisted.cards - 1, String(afterDelete));

    check('aucune erreur JavaScript dans la page', app.pageErrors.length === 0,
      app.pageErrors.slice(0, 3).join(' | '));
  } finally {
    app.close();
  }

  console.log(failures === 0 ? '\nTOUS LES CONTROLES PASSENT' : `\n${failures} controle(s) en echec`);
  process.exit(failures === 0 ? 0 : 1);
}

main().catch((err) => {
  console.error('ECHEC DU TEST :', err.message);
  process.exit(1);
});
